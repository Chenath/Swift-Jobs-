//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

import dotenv from "dotenv";
import OpenAI from "openai";
import express from "express";
dotenv.config();

//authenticat with our API keys
const openai = new OpenAI({
    apikey: process.env.OPEN_AI_KEY,
});

const PORT = process.env.PORT || 9090;
const app = express();

//! pass incoming json data (Pass the JSON data to the server)
app.use(express.json());

//! Globale varable to hold the conversation history
let conversationHistory = [{role: 'system', content: 'You are a helpful assistant.'}];



//! Routes
app.post('/ask', async(req, res) => {
    const usermessage = req.body.message;
    // Update the conversationHistory with the user's message
    conversationHistory.push({role: 'user', content: usermessage});
    // talk to the model
    try {
        const completion = await openai.chat.completions.create({conversationHistory, model: "gpt-4o-mini"});
        //Extract the response from the completion
        const botResponse = completion.choices[0].message.content;
        //Send the response
        res.json({message: botResponse});
    } catch (error) {
        res.status(500).json({message: 'Error geting respose from openAI (Internal server error)'});
    }
});



//! Run the server
app.listen(PORT, console.log('server is running on the poart ${port}... '));



// const completion = await openai.chat.completions.create({
//     model: "gpt-4o-mini",
//     messages: [
//         { role: "developer", content: "You are a helpful assistant." },
//         {
//             role: "user",
//             content: "Who is the president in Srlanka?",
//         },
//     ],
//     store: true,
// });

// console.log(completion.choices[0].message);